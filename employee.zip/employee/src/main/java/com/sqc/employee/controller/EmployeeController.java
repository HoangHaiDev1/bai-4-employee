package com.sqc.employee.controller;

import com.sqc.employee.model.Employee;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;


@RestController
@RequestMapping("/")
public class EmployeeController {

    private final List<Employee> employees = new ArrayList<>(
            Arrays.asList(
                    new Employee(UUID.randomUUID(), "Nguyen Van A", LocalDate.of(1990, 1, 2), Employee.Gender.MALE, 15555555, "0123456789"),
                    new Employee(UUID.randomUUID(), "Nguyen Van B", LocalDate.of(2000, 2, 3), Employee.Gender.FEMALE, 1000000, "0987654321"),
                    new Employee(UUID.randomUUID(), "Nguyen Van C", LocalDate.of(1998, 1, 4), Employee.Gender.OTHER, 200000, "012987789")
                    )
    );
    // get
    @GetMapping("employee-all")
    public ResponseEntity<List<Employee>> employeeAll() {
        return ResponseEntity.ok(employees);
    }

    @GetMapping("employee/{id}")
    public ResponseEntity<Employee> employeeId(@PathVariable("id") UUID id) {
       return employees.stream()
               .filter(e -> e.getId().equals(id))
               .findFirst()
               .map(ResponseEntity::ok)
               .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("employee")
    public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee) {
        employee.setId(UUID.randomUUID());
        employees.add(employee);
        return ResponseEntity.ok(employee);
    }

    @PutMapping("/employee/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable("id") UUID id,  @RequestBody Employee employee) {
        return employees.stream()
                .filter(e -> e.getId().equals(id))
                .findFirst()
                .map(e -> {
                    e.setId(employee.getId());
                    e.setName(employee.getName());
                    e.setGender(employee.getGender());
                    e.setSalary(employee.getSalary());
                    e.setBirthDate(employee.getBirthDate());
                    e.setPhoneNumber(employee.getPhoneNumber());
                    return ResponseEntity.ok(e);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("employee/{id}")
    public ResponseEntity<String> deleteEmployee(@PathVariable("id") UUID id) {
        boolean removed = employees.removeIf(e -> e.getId().equals(id));
        if (removed) {
            return ResponseEntity.ok("Đã xóa thành công");
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
