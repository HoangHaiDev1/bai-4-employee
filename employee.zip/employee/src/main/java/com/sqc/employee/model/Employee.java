package com.sqc.employee.model;
import java.time.LocalDate;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

import java.time.LocalDate;
import java.util.UUID;

public class Employee {

    private UUID id;
    private String name;
    private LocalDate birthDate;
    private Gender gender;
    private int salary;
    private String phoneNumber;

    // Enum for gender
    public enum Gender {
        MALE, FEMALE, OTHER
    }

    // Constructor
    public Employee(UUID id, String name, LocalDate birthDate, Gender gender, int salary, String phoneNumber) {
        this.id = id;
        this.name = name;
        this.birthDate = birthDate;
        this.gender = gender;
        this.salary = salary;
        this.phoneNumber = phoneNumber;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    // Getters and setters (if needed)
    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public Gender getGender() {
        return gender;
    }

    public int getSalary() {
        return salary;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

}
